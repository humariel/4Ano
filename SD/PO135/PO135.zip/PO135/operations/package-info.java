/**
 * Package containing all the interfaces implemented by the different monitors. 
 * These interfaces limit how an entity/thread interacts with a given monitor.
 */

 package operations;