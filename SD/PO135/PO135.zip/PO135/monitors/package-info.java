/**
 * Package containing the shared memmory regions used in the solution. 
 */

package monitors;