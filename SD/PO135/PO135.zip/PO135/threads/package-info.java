/**
 * Package containing the different enteties used in the problem, 
 * namely: Passenger, BusDriver and Porter.
 */

package threads;