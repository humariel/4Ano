/**
 * Package containing all the enums that represent the states each entity 
 * goes through during it's life cycle.
 */

 package enums;